Special Delivery
----------------

Version 0.1
Small parts mod for cargo spacecraft.


Install
----------------
Merge the GameData folder in this ZIP with the GameData folder in your KSP installation.
The folder "Delivery" should sit alongside the "Squad" folder.

Contents
----------------
- Cygnus spacecraft (KIS compatible).

License
----------------
MIT license